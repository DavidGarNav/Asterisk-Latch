#!/bin/bash
mkdir /etc/asterisk/latch
cp AppBlock.jar /etc/asterisk/latch/
cp messageLatch /etc/asterisk/latch/
echo "#define PROXYADDRESS       \"$1\"" >> res_latch.h
echo "#define MANAGERIP    \"$2\"" >> res_latch.h
echo "#define MANAGERNAME    \"$3\"" >> res_latch.h
echo "#define MANAGERSECRET    \"$4\"" >> res_latch.h
gcc -o res_latch.o -c res_latch.c -MD -MT res_latch.o -MF .res_latch.o.d -MP -pthread  -Wno-unused-result -I/home/davidgn/asterisk/asterisk-1.6.2.24/include   -I/usr/include/libxml2 -pipe -Wall -Wstrict-prototypes -Wmissing-prototypes -Wmissing-declarations -g3 -march=i686  -O6  -fPIC -DAST_MODULE=\"res_latch\" 
gcc -o latch.o -c latch.c -lcurl -lcrypto -lssl -ld
gcc  -o res_latch.so -pthread  -shared  res_latch.o latch.o -L/usr/lib/i386-linux-gnu -lcurl -Wl,-Bsymbolic-functions -Wl,-z,relro
install -m 755 res_latch.so /usr/lib/asterisk/modules
