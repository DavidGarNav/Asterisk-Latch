#ifndef AST_MODULE
#define AST_MODULE "res_latch.so"
#endif

#include "asterisk.h"

ASTERISK_FILE_VERSION(__FILE__, "$Revision: $")

#include "asterisk/cli.h"
#include "asterisk/logger.h"
#include "asterisk/module.h"  
#include "asterisk/strings.h"
#include "latch.h"
#include "sqlite3.h"
#include "res_latch.h"
#include <stdlib.h>
#include <string.h>


int pairing_status(char *pUserID, struct ast_cli_args *pa){


  char app[21]="app";
  char secret[41]="secret";
  char accountID[65]="accountID";
  char *response;
  int result=NOT_PAIRED;
  init(app, secret);
  if(strlen(PROXYADDRESS)!=4)
    setProxy(PROXYADDRESS);
  setNoSignal(1);

  select_app_secret(pUserID,app,secret,pa);

  if (strlen(app)!=3){ //User exists in Database.

    select_accountid(pUserID,accountID,pa);
    response = status(accountID);
    ast_cli(pa->fd, "%s\n\n", response);

    if ((strlen(response)==64)&&(response[2]=='d') ){
      //The account is paired:

      result=PAIRED;
    }
    else if((strlen(response)==65)&&(response[2]=='d')){
      //The account is paired.

      result=PAIRED;
    }
    else {
      //Error. The account is not paired:

      result=NOT_PAIRED;
    }
  }
  return result;
}


int start_app_block(struct ast_cli_args *pa)
{


  

  sqlite3 *db;
  char *zErrMsg = 0;
  int  rc;
  int result=NO_ERROR_DB;
  sqlite3_stmt *pStmt;

  /* Open database */
  rc = sqlite3_open("/etc/asterisk/latch/AsteriskLatchCommDB.db", &db);
  if( rc ){

    result=ERROR_DB;
  }else{


    

    char sql[160] = "SELECT USERID FROM USERS;";
    



    rc= sqlite3_prepare_v2(db, sql,-1,&pStmt,NULL);
    if( rc != SQLITE_OK ){

      sqlite3_free(zErrMsg);
      sqlite3_close(db);
      result=SQLITE_ERROR;
    }else{


      rc= sqlite3_step(pStmt);


      if( rc == SQLITE_DONE ){


	sqlite3_finalize(pStmt);
	sqlite3_close(db);
	result=NO_ERROR_DB;
      }
      else if ( rc == SQLITE_ROW )
	{
	  while( rc != SQLITE_DONE)
	    {

	      char *tempUserID=sqlite3_column_text(pStmt,0);
	      if (pairing_status(tempUserID,pa)==PAIRED){
		char command[350]= "java -jar /etc/asterisk/latch/AppBlockCommunityAccount.jar ";
		strcat(command,tempUserID);
		strcat(command," ");
		strcat(command,MANAGERIP);
		strcat(command," ");
		strcat(command,MANAGERNAME);
		strcat(command," ");
		strcat(command,MANAGERSECRET);
		strcat(command, " &");		
		
		  
		system(command); //Launching the blocking application when the account is paired.
	      }
              rc= sqlite3_step(pStmt);
	    }
	
	  sqlite3_finalize(pStmt);
	  sqlite3_close(db);
	  result=NO_ERROR_DB;
	}
      else
	{

	  sqlite3_free(zErrMsg);
	  sqlite3_close(db);
	  result=SQLITE_ERROR;
	
	}
    } 
  }



  return result;


}





int channel_exists(char *pChannel,struct ast_cli_args *pa)
{


  

  sqlite3 *db;
  char *zErrMsg = 0;
  int  rc;
  int result=CHANNEL_EXISTS;
  sqlite3_stmt *pStmt;

  /* Open database */
  rc = sqlite3_open("/etc/asterisk/latch/AsteriskLatchCommDB.db", &db);
  if( rc ){
    ast_cli(pa->fd, "Can't open database: %s\n", sqlite3_errmsg(db));
    result=ERROR_DB;
  }else{
    ast_cli(pa->fd, "Opened database successfully\n");

    

    char sql[160] = "SELECT * FROM DEVICES WHERE CHANNEL='";
    
    strcat(sql,pChannel);
    
    strcat(sql,"';");
    ast_cli(pa->fd, " %s\n", sql);


    rc= sqlite3_prepare_v2(db, sql,-1,&pStmt,NULL);
    if( rc != SQLITE_OK ){
      ast_cli(pa->fd, "SQL error: %s\n", zErrMsg);
      sqlite3_free(zErrMsg);
      sqlite3_close(db);
      result=SQLITE_ERROR;
    }else{
      ast_cli(pa->fd, "PREPARE SUCCESS\n");

      rc= sqlite3_step(pStmt);
      ast_cli(pa->fd, "VALOR DE RC  %d\n", rc);

      if( rc == SQLITE_DONE ){

	ast_cli(pa->fd, "Channel NOT found in database\n");
	sqlite3_finalize(pStmt);
	sqlite3_close(db);
	result=CHANNEL_NOT_EXISTS;
      }
      else if ( rc == SQLITE_ROW )
	{
	  ast_cli(pa->fd, "Channel found in database\n");
	  sqlite3_finalize(pStmt);
	  sqlite3_close(db);
	  result=CHANNEL_EXISTS;

	}
      else
	{
	  ast_cli(pa->fd, "SQL error: %s\n", zErrMsg);
	  sqlite3_free(zErrMsg);
	  sqlite3_close(db);
	  result=SQLITE_ERROR;
	
	}
    } 
  }



  return result;


}
int update_table(char * pUserID,char *pAccountID, struct ast_cli_args *pa)
{


  

  sqlite3 *db;
  char *zErrMsg = 0;
  int  rc;
  int result; //

  /* Open database */
  rc = sqlite3_open("/etc/asterisk/latch/AsteriskLatchCommDB.db", &db);
  if( rc ){
    ast_cli(pa->fd, "Can't open database: %s\n", sqlite3_errmsg(db));
    result=ERROR_DB;
  }else{
    ast_cli(pa->fd, "Opened database successfully\n");
    ast_cli(pa->fd, "%s\n", pAccountID);
    

    char sql[160] = "UPDATE USERS SET ACCOUNTID ='";

    strcat(sql,pAccountID);

    strcat(sql,"' WHERE USERID='");

    strcat(sql,pUserID);

    strcat(sql,"';");
    ast_cli(pa->fd, " %s\n", sql);


    rc = sqlite3_exec(db, sql, NULL, 0, &zErrMsg);
    if( rc != SQLITE_OK ){
      ast_cli(pa->fd, " %s\n", sql);
      ast_cli(pa->fd, "SQL error: %s\n", zErrMsg);
      sqlite3_free(zErrMsg);
      sqlite3_close(db);
      result=ERROR_DB;

    }else{
      ast_cli(pa->fd, "Records updated successfully\n");
  	   


      sqlite3_close(db);
      result=NO_ERROR_DB;
	
    } //bloque records created
  
	 


  }
  return result;




}


char *get_accountID(char * pResponse,char pAccountID[],struct ast_cli_args *pa)
{
  
  
  const char *subString=strstr(pResponse,"\":\"");
  
  

  ast_copy_string(pAccountID,subString+3,65);
 
 


  return "a";


}


char *get_operationID(char * pResponse,char pOperationID[],struct ast_cli_args *pa)
{
  
  
  const char *subString=strstr(pResponse,"\":\"");
  
  

  ast_copy_string(pOperationID,subString+3,21);
 
 


  return "a";


}
int select_app_secret(char * pUserID, char papp[],char psecret[], struct ast_cli_args *pa)
{
  int i=0;
  sqlite3 *db;
  char *zErrMsg = 0;
  int  rc;
  sqlite3_stmt *pStmt;
  /* Open database */
  rc = sqlite3_open("/etc/asterisk/latch/AsteriskLatchCommDB.db", &db);
  if( rc ){
    ast_cli(pa->fd, "Can't open database: %s\n", sqlite3_errmsg(db));
    return SQLITE_ERROR;
  }else{
    ast_cli(pa->fd, "Opened database successfully\n");
	   
    /* Create SQL statement */
    char sql[160] = "SELECT APPID, SECRET FROM USERS WHERE USERID='";

    strcat(sql,pUserID);

    strcat(sql,"';");
    ast_cli(pa->fd, " %s\n", sql);

    /* Execute SQL statement */

    rc= sqlite3_prepare_v2(db, sql,-1,&pStmt,NULL);
    if( rc != SQLITE_OK ){
      ast_cli(pa->fd, "SQL error: %s\n", zErrMsg);
      sqlite3_free(zErrMsg);
      sqlite3_close(db);
      return SQLITE_ERROR;
    }else{
      ast_cli(pa->fd, "PREPARE SUCCESS\n");

      rc= sqlite3_step(pStmt);
      if( rc != SQLITE_ROW ){
	ast_cli(pa->fd, "SQL error: %s\n", zErrMsg);
	sqlite3_free(zErrMsg);
	sqlite3_close(db);
	return SQLITE_ERROR;
      }else{
	  
	ast_cli(pa->fd, "STEP SUCCESS\n");
	for( i=0; i<=1; i++){
	  ast_cli(pa->fd, "%s\n",sqlite3_column_text(pStmt,i));
	    
	}
	const char *temp=sqlite3_column_text(pStmt,0);
	ast_copy_string(papp,temp,21);
	temp=sqlite3_column_text(pStmt,1);
	ast_copy_string(psecret,temp,41);
	   
	   

	sqlite3_finalize(pStmt);
	sqlite3_close(db);

      } 
    } 
    

  } 
 
  return SQLITE_OK;

}


int select_accountid(char * pUserID, char pAccountID[], struct ast_cli_args *pa)
{
    
  sqlite3 *db;
  char *zErrMsg = 0;
  int  rc;
  sqlite3_stmt *pStmt;
  /* Open database */
  rc = sqlite3_open("/etc/asterisk/latch/AsteriskLatchCommDB.db", &db);
  if( rc ){
    ast_cli(pa->fd, "Can't open database: %s\n", sqlite3_errmsg(db));
    return SQLITE_ERROR;
  }else{
    ast_cli(pa->fd, "Opened database successfully\n");
	   
    /* Create SQL statement */
    char sql[160] = "SELECT ACCOUNTID FROM USERS WHERE USERID='";

    strcat(sql,pUserID);

    strcat(sql,"';");
    ast_cli(pa->fd, " %s\n", sql);

    /* Execute SQL statement */

    rc= sqlite3_prepare_v2(db, sql,-1,&pStmt,NULL);
    if( rc != SQLITE_OK ){
      ast_cli(pa->fd, "SQL error: %s\n", zErrMsg);
      sqlite3_free(zErrMsg);
      sqlite3_close(db);
      return SQLITE_ERROR;
    }else{
      ast_cli(pa->fd, "PREPARE SUCCESS\n");

      rc= sqlite3_step(pStmt);
      if( rc != SQLITE_ROW ){
	ast_cli(pa->fd, "SQL error: %s\n", zErrMsg);
	sqlite3_free(zErrMsg);
	sqlite3_close(db);
	return SQLITE_ERROR;
      }else{
	  
	ast_cli(pa->fd, "STEP SUCCESS\n");
	   
	ast_cli(pa->fd, "%s\n",sqlite3_column_text(pStmt,0));
	    
      
	const char *temp=sqlite3_column_text(pStmt,0);
	ast_copy_string(pAccountID,temp,65);

	   
	   

	sqlite3_finalize(pStmt);
	sqlite3_close(db);

      } //este ultimo else
    } // bloque database open
    

  } //dentro del pair
 
  return SQLITE_OK;

}


int select_operationid(char * pChannel, char pOperationID[], struct ast_cli_args *pa)
{
    
  sqlite3 *db;
  char *zErrMsg = 0;
  int  rc;
  sqlite3_stmt *pStmt;
  /* Open database */
  rc = sqlite3_open("/etc/asterisk/latch/AsteriskLatchCommDB.db", &db);
  if( rc ){
    ast_cli(pa->fd, "Can't open database: %s\n", sqlite3_errmsg(db));
    return SQLITE_ERROR;
  }else{
    ast_cli(pa->fd, "Opened database successfully\n");
	   
    /* Create SQL statement */
    char sql[160] = "SELECT OPERATIONID FROM DEVICES WHERE CHANNEL='";

    strcat(sql,pChannel);

    strcat(sql,"';");
    ast_cli(pa->fd, " %s\n", sql);

    /* Execute SQL statement */

    rc= sqlite3_prepare_v2(db, sql,-1,&pStmt,NULL);
    if( rc != SQLITE_OK ){
      ast_cli(pa->fd, "SQL error: %s\n", zErrMsg);
      sqlite3_free(zErrMsg);
      sqlite3_close(db);
      return SQLITE_ERROR;
    }else{
      ast_cli(pa->fd, "PREPARE SUCCESS\n");

      rc= sqlite3_step(pStmt);
      if( rc != SQLITE_ROW ){
	ast_cli(pa->fd, "SQL error: %s\n", zErrMsg);
	sqlite3_free(zErrMsg);
	sqlite3_close(db);
	return SQLITE_ERROR;
      }else{
	  
	ast_cli(pa->fd, "STEP SUCCESS\n");
	   
	ast_cli(pa->fd, "%s\n",sqlite3_column_text(pStmt,0));
	    
      
	const char *temp=sqlite3_column_text(pStmt,0);
	ast_copy_string(pOperationID,temp,21);

	   
	   

	sqlite3_finalize(pStmt);
	sqlite3_close(db);

      } 
    } 
    

  } 
 
  return SQLITE_OK;

}


int eliminate_from_table_users(char *pUserID,struct ast_cli_args *pa)
{

  

  sqlite3 *db;
  char *zErrMsg = 0;
  int  rc;
  int result; //

  /* Open database */
  rc = sqlite3_open("/etc/asterisk/latch/AsteriskLatchCommDB.db", &db);
  if( rc ){
    ast_cli(pa->fd, "Can't open database: %s\n", sqlite3_errmsg(db));
    result=ERROR_DB;
  }else{
    ast_cli(pa->fd, "Opened database successfully\n");


    char sql[160] = "DELETE FROM USERS WHERE USERID='";

    strcat(sql,pa->argv[2]);

    strcat(sql,"';");
    ast_cli(pa->fd, " %s\n", sql);

    rc = sqlite3_exec(db, sql, NULL, 0, &zErrMsg);
    if( rc != SQLITE_OK ){
      ast_cli(pa->fd, " %s\n", sql);
      ast_cli(pa->fd, "SQL error: %s\n", zErrMsg);
      sqlite3_free(zErrMsg);
      sqlite3_close(db);
      result=ERROR_DB;

    }else{
      ast_cli(pa->fd, "Records deleted successfully\n");
  	   


      sqlite3_close(db);
      result=NO_ERROR_DB;
	
    } 
  
	 


  }
  return result;
}

int eliminate_from_table_devices(char *pChannel,struct ast_cli_args *pa)
{

  

  sqlite3 *db;
  char *zErrMsg = 0;
  int  rc;
  int result; //

  /* Open database */
  rc = sqlite3_open("/etc/asterisk/latch/AsteriskLatchCommDB.db", &db);
  if( rc ){
    ast_cli(pa->fd, "Can't open database: %s\n", sqlite3_errmsg(db));
    result=ERROR_DB;
  }else{
    ast_cli(pa->fd, "Opened database successfully\n");


    char sql[160] = "DELETE FROM DEVICES WHERE CHANNEL='";

    strcat(sql,pChannel);

    strcat(sql,"';");
    ast_cli(pa->fd, " %s\n", sql);

    rc = sqlite3_exec(db, sql, NULL, 0, &zErrMsg);
    if( rc != SQLITE_OK ){
      ast_cli(pa->fd, " %s\n", sql);
      ast_cli(pa->fd, "SQL error: %s\n", zErrMsg);
      sqlite3_free(zErrMsg);
      sqlite3_close(db);
      result=ERROR_DB;

    }else{
      ast_cli(pa->fd, "Records deleted successfully\n");
  	   


      sqlite3_close(db);
      result=NO_ERROR_DB;
	
    } 
  
	 


  }
  return result;
}


int insert_in_table(char *pUserID, char *pAppID, char *pSecret,struct ast_cli_args *pa)
{
  

  sqlite3 *db;
  char *zErrMsg = 0;
  char * sql;
  int  rc;
  int result; //

  /* Open database */
  rc = sqlite3_open("/etc/asterisk/latch/AsteriskLatchCommDB.db", &db);
  if( rc ){
    ast_cli(pa->fd, "Can't open database: %s\n", sqlite3_errmsg(db));
    result=ERROR_DB;
  }else{
    ast_cli(pa->fd, "Opened database successfully\n");
	   
    /* Create SQL statement */
    sql = "CREATE TABLE IF NOT EXISTS USERS("  \
      "USERID 	CHAR(100)	PRIMARY KEY     NOT NULL," \
      "APPID          CHAR(20)," \
      "SECRET         CHAR(40)," \
      "ACCOUNTID      CHAR(64));";

    /* Execute SQL statement */


    rc = sqlite3_exec(db, sql, NULL, 0, &zErrMsg);
    if( rc != SQLITE_OK ){
      ast_cli(pa->fd, "SQL error: %s\n", zErrMsg);
      sqlite3_free(zErrMsg);
      sqlite3_close(db);
      result=ERROR_DB;
    }else{
      ast_cli(pa->fd, "Table created successfully\n");
	   

      char sql1[160] = "INSERT INTO USERS(USERID,APPID,SECRET) " \
	"VALUES ('";

      strcat(sql1,pa->argv[2]);

      strcat(sql1,"','");

      strcat(sql1,pa->argv[3]);

      strcat(sql1,"','");

      strcat(sql1,pa->argv[4]);

      strcat(sql1,"');");

      ast_cli(pa->fd, " %s\n", sql1);

      rc = sqlite3_exec(db, sql1, NULL, 0, &zErrMsg);
      if( rc != SQLITE_OK ){
	ast_cli(pa->fd, " %s\n", sql1);
	ast_cli(pa->fd, "SQL error: %s\n", zErrMsg);
	sqlite3_free(zErrMsg);
	sqlite3_close(db);
	result=ERROR_DB;

      }else{
	ast_cli(pa->fd, "Records created successfully\n");
  	   


	sqlite3_close(db);
	result=NO_ERROR_DB;
	
      } 
    } 
  } 
  
  return result;

}

void create_table_devices(struct ast_cli_args *pa){
  sqlite3 *db;
  char *zErrMsg = 0;
  char * sql;
  int  rc;
  int result; //

  /* Open database */
  rc = sqlite3_open("/etc/asterisk/latch/AsteriskLatchCommDB.db", &db);
  if( rc ){
    ast_cli(pa->fd, "Can't open database: %s\n", sqlite3_errmsg(db));
    result=ERROR_DB;
  }else{
    ast_cli(pa->fd, "Opened database successfully\n");
	   
    /* Create SQL statement */
    sql = "CREATE TABLE IF NOT EXISTS DEVICES("  \
      "CHANNEL 	CHAR(100)	PRIMARY KEY     NOT NULL," \
      "OPERATIONID    CHAR(20)," \
      "USERID 	      CHAR(100)," \
      "APPID          CHAR(20)," \
      "SECRET         CHAR(40)," \
      "ACCOUNTID      CHAR(64));";

    /* Execute SQL statement */


    rc = sqlite3_exec(db, sql, NULL, 0, &zErrMsg);
    if( rc != SQLITE_OK ){
      ast_cli(pa->fd, "SQL error: %s\n", zErrMsg);
      sqlite3_free(zErrMsg);
      sqlite3_close(db);
      result=ERROR_DB;
    }else{
      ast_cli(pa->fd, "Table created successfully\n");
    }
  }



}
int insert_in_table_devices(char *pChannel, char *pOperationID,char *pUserID, char *pAppID, char *pSecret,char *pAccountID,struct ast_cli_args *pa)

{
  

  sqlite3 *db;
  char *zErrMsg = 0;
  char * sql;
  int  rc;
  int result; //

  /* Open database */
  rc = sqlite3_open("/etc/asterisk/latch/AsteriskLatchCommDB.db", &db);
  if( rc ){
    ast_cli(pa->fd, "Can't open database: %s\n", sqlite3_errmsg(db));
    result=ERROR_DB;
  }else{
    ast_cli(pa->fd, "Opened database successfully\n");
	   
    /* Create SQL statement */
    sql = "CREATE TABLE IF NOT EXISTS DEVICES("  \
      "CHANNEL 	CHAR(100)	PRIMARY KEY     NOT NULL," \
      "OPERATIONID    CHAR(20)," \
      "USERID 	      CHAR(100)," \
      "APPID          CHAR(20)," \
      "SECRET         CHAR(40)," \
      "ACCOUNTID      CHAR(64));";

    /* Execute SQL statement */


    rc = sqlite3_exec(db, sql, NULL, 0, &zErrMsg);
    if( rc != SQLITE_OK ){
      ast_cli(pa->fd, "SQL error: %s\n", zErrMsg);
      sqlite3_free(zErrMsg);
      sqlite3_close(db);
      result=ERROR_DB;
    }else{
      ast_cli(pa->fd, "Table created successfully\n");
	   

      char sql1[350] = "INSERT INTO DEVICES(CHANNEL,OPERATIONID,USERID,APPID,SECRET,ACCOUNTID) " \
	"VALUES ('";

      strcat(sql1,pChannel);

      strcat(sql1,"','");

      strcat(sql1,pOperationID);

      strcat(sql1,"','");

      strcat(sql1,pUserID);

      strcat(sql1,"','");

      strcat(sql1,pAppID);
      strcat(sql1,"','");

      strcat(sql1,pSecret);
      strcat(sql1,"','");

      strcat(sql1,pAccountID);
      strcat(sql1,"');");

      ast_cli(pa->fd, " %s\n", sql1);

      rc = sqlite3_exec(db, sql1, NULL, 0, &zErrMsg);
      if( rc != SQLITE_OK ){
	ast_cli(pa->fd, " %s\n", sql1);
	ast_cli(pa->fd, "SQL error: %s\n", zErrMsg);
	sqlite3_free(zErrMsg);
	sqlite3_close(db);
	result=ERROR_DB;

      }else{
	ast_cli(pa->fd, "Records created successfully\n");
  	   


	sqlite3_close(db);
	result=NO_ERROR_DB;
	
      } 
    } 
  } 
  

  return result;

}



void create(char *pUserID, char *pAppID, char *pSecret,struct ast_cli_args *pa)
{

  int result;
  char accountID[65]="accountID";
  ast_cli(pa->fd, "%s\n\n", pUserID);
  ast_cli(pa->fd, "%s\n\n", pAppID);
  ast_cli(pa->fd, "%s\n\n", pSecret);
  
  result=insert_in_table(pUserID,pAppID,pSecret,pa);
  update_table(pUserID,accountID,pa);
  create_table_devices(pa);
  ast_cli(pa->fd, "%d\n\n", result);
  
}

void eliminate(char *pUserID, struct ast_cli_args *pa)
{

  int result;
  ast_cli(pa->fd, "%s\n\n", pUserID);

  unpairing(pUserID,pa);//Unpairing before eliminate user.

  result=eliminate_from_table_users(pUserID,pa);
  ast_cli(pa->fd, "%d\n\n", result);
  
}

void pairing(char *pUserID,char *pToken, struct ast_cli_args *pa)
{


  int i;
  char app[21]="app";
  char secret[41]="secret";
  char accountID[65]="accountID";


  select_app_secret(pUserID,app,secret,pa);
  
  if (strlen(app)!=3){ //User exists in Database.

    ast_cli(pa->fd, "Dentro de pairing\n\n");
    for(i=0;i<=19;i++)
      ast_cli(pa->fd, "%c", app[i]);
    ast_cli(pa->fd, "\n\n");
 

    for(i=0;i<=39;i++)
      ast_cli(pa->fd, "%c", secret[i]);
    ast_cli(pa->fd, "\n\n");

    
    init(app, secret);
    if(strlen(PROXYADDRESS)!=4)
      setProxy(PROXYADDRESS);
    setNoSignal(1);

    char *response = pair(pToken);
    ast_cli(pa->fd, "%s\n\n", response);

    if (strlen(response)!=89)
      {
	ast_cli(pa->fd, "An error occurred while pairing account\n\n");

      }
    else
      {
	get_accountID(response,accountID,pa);
	for(i=0;i<=63;i++)
	  ast_cli(pa->fd, "%c", accountID[i]);
	ast_cli(pa->fd, "\n\n");

	if((update_table(pUserID,accountID,pa))==ERROR_DB)
	  {
	    ast_cli(pa->fd, "An error occurred while saving data in database. Account not paired.\n\n");

	    unpairing(pUserID,pa); //If there is an error saving the data in database, the account is unpaired.
	  }
	else
	  {
	    ast_cli(pa->fd, "Account  paired\n\n");
	    char command[250]= "java -jar /etc/asterisk/latch/AppBlockCommunityAccount.jar ";
	    strcat(command,pUserID);
	    strcat(command," ");
	    strcat(command,MANAGERIP);
	    strcat(command," ");
	    strcat(command,MANAGERNAME);
	    strcat(command," ");
	    strcat(command,MANAGERSECRET);
	    strcat(command, " &");
	    system(command); //Launching the blocking application when the account is paired.
	  }
      }
  }
}

void unpairing(char *pUserID, struct ast_cli_args *pa)
{


  char app[21]="app";
  char secret[41]="secret";
  char * response;
  int i;
  char accountID[65];


  select_app_secret(pUserID,app,secret,pa);
  if (strlen(app)!=3){ //User exists in Database.

    select_accountid(pUserID,accountID,pa);
    for(i=0;i<=63;i++)
      ast_cli(pa->fd, "%c", accountID[i]);

    init(app, secret);
    if(strlen(PROXYADDRESS)!=4)
      setProxy(PROXYADDRESS);
    setNoSignal(1);


    response=unpair(accountID);
    ast_cli(pa->fd, "\n\n%s\n\n", response);
    ast_cli(pa->fd, "%d\n\n", strlen(response));
    if (strlen(response)!=2)
      {
	ast_cli(pa->fd, "An error occurred while unpairing account\n\n");

      }
    else
      {
	ast_cli(pa->fd, "Account unpaired\n\n");
	char command[250]= "pkill -9 -f \"/etc/asterisk/latch/AppBlockCommunityAccount.jar ";
	strcat(command,pUserID);
	strcat(command, "\" &");
	system(command); //Killing the blocking application when the account is unpaired.
      }
  }
}


void add_channel(char *pUserID, char *pChannel, struct ast_cli_args *pa)
{
  int i;
  char app[21]="app";
  char secret[41]="secret";
  char accountID[65]="accountID";
  char operationID[21]="operationID";
  char *response;

  select_app_secret(pUserID,app,secret,pa);
  if (strlen(app)!=3){ //User exists in Database.

    select_accountid(pUserID,accountID,pa);
    for(i=0;i<=63;i++)
      ast_cli(pa->fd, "%c", accountID[i]);

    init(app, secret);
    if(strlen(PROXYADDRESS)!=4)
      setProxy(PROXYADDRESS);
    setNoSignal(1);

    if (channel_exists(pChannel,pa)==CHANNEL_EXISTS)
      {
	ast_cli(pa->fd, "Channel already exists\n");

      }
    else if  (channel_exists(pChannel,pa)==CHANNEL_NOT_EXISTS)
      {
	ast_cli(pa->fd, "          Channel NOT exists\n");
	response=operationCreate(app,pChannel,"DISABLED", "DISABLED");
	ast_cli(pa->fd, "%s\n", response);
      

	if (strlen(response)!=47)
	  {
	    ast_cli(pa->fd, "An error ocurred while adding a newdevice\n\n");

	  }
	else
	  {
	    get_operationID(response,operationID,pa);
	    if(insert_in_table_devices(pChannel,operationID,pUserID,app,secret,accountID,pa)==ERROR_DB)
	      {
		ast_cli(pa->fd, "An error occurred while saving data in database. Device not added.\n\n");
		remove_channel(pUserID,pChannel,pa);

	      }
	    else
	      {
		ast_cli(pa->fd, "Device added correctly.\n\n");

	      }
     
	  }
      
      }
    
    else 
      {
	ast_cli(pa->fd, "Database ERROR\n");


     
      }
  }
}


void remove_channel(char *pUserID, char *pChannel, struct ast_cli_args *pa)

{
  int i;
  char app[21]="app";
  char secret[41]="secret";
  char operationID[21]="operationID";
  char *response;

  select_app_secret(pUserID,app,secret,pa);
  
  if (strlen(app)!=3){ //User exists in Database.

    if (channel_exists(pChannel,pa)==CHANNEL_EXISTS)
      {
	ast_cli(pa->fd, "Channel exists\n");
	select_operationid(pChannel,operationID,pa);
	for(i=0;i<=19;i++)
	  ast_cli(pa->fd, "%c", operationID[i]);

	init(app, secret);
	if(strlen(PROXYADDRESS)!=4)
	  setProxy(PROXYADDRESS);
	setNoSignal(1);

	response=operationRemove(operationID);
	ast_cli(pa->fd, "%s\n", response);
	if (strlen(response)>2)
	  {
	    ast_cli(pa->fd, "ERROR%s", response);
	  }
	else
	  {
	  
	    if (eliminate_from_table_devices(pChannel,pa)==ERROR_DB) //If operation was eliminated from Latch application but error happened while trying 
	      {                                                      //to eliminate channel from database.Operation is added to Latch again.
		ast_cli(pa->fd, "Error while trying to delete channel from database. Channel not removed from Latch\n");
		add_channel(pUserID,pChannel,pa);

	      }
	    ast_cli(pa->fd, "Operation removed%s\n", response);

	  }
      }
    else if  (channel_exists(pChannel,pa)==CHANNEL_NOT_EXISTS)
      {
	ast_cli(pa->fd, " Channel NOT exists\n");
      
      }
    
    else 
      {
	ast_cli(pa->fd, "Database ERROR\n");


     
      }
  }
}


static char *handle_cli_latch(struct ast_cli_entry *e, int cmd, struct ast_cli_args *a)
{
  int i;

  switch (cmd) {
  case CLI_INIT:
    e->command = "latch";
    e->usage =
      "Usage:\n"
      "latch create <userID> <appID> <secret>\n"
      "      Create a new user.\n\n"
      "latch eliminate <userID> \n"
      "      Eliminate a new user.\n\n"
      "latch pair  <userID> <toke>\n"
      "      Pair a user.\n\n"
      "latch unpair <userID> \n"
      "      Unpair a user.\n\n"
      "latch add <userID> <channel> <channel> ... \n"
      "      Add channels/phones to control.\n\n"
      "latch remove <userID> <channel> <channel> ... \n"
      "      Remove channels/phones to be controlled.\n\n"
      "";
    return NULL;
  case CLI_GENERATE:
    return NULL;
  }

  if (a->argc == e->args) {
    ast_cli(a->fd, "Invalid arguments. You did not provide <user> and <token>\n\n");
    return CLI_SHOWUSAGE;
  }
  
  else{

    if(strcmp((a->argv[1]),"create")==0)
      {
	if ((a->argc)==5){
	  create(a->argv[2],a->argv[3], a->argv[4],a);
	}
	else{
	  return CLI_SHOWUSAGE;
	}

      }

    else if(strcmp((a->argv[1]),"eliminate")==0)
      {
	if ((a->argc)==3){
	  eliminate(a->argv[2],a);
	}	
	else{
	  return CLI_SHOWUSAGE;
	}
      }
      

    else if(strcmp((a->argv[1]),"pair")==0)
      {
	if ((a->argc)==4){
	  pairing(a->argv[2],a->argv[3],a);
	}	
	else{
	  return CLI_SHOWUSAGE;
	}
      }
	
  


    else if(strcmp((a->argv[1]),"unpair")==0)
      {
	if ((a->argc)==3){
	  unpairing(a->argv[2],a);
	}	
	else{
	  return CLI_SHOWUSAGE;
	}
      }
	

      
    else if(strcmp((a->argv[1]),"add")==0)
      {
	if ((a->argc)>3){
	  for (i=0; i<=((a->argc)-4);i++)
	    add_channel(a->argv[2],a->argv[i+3],a); 
	}	
	else{
	  return CLI_SHOWUSAGE;
	}
      }


      
    else if(strcmp((a->argv[1]),"remove")==0)
      {
	if ((a->argc)>3){
        
	  for (i=0; i<=((a->argc)-4);i++)
	    remove_channel(a->argv[2],a->argv[i+3],a); 

	}	
	else{
	  return CLI_SHOWUSAGE;
	}
	
      }

    else if(strcmp((a->argv[1]),"start")==0)
      {
	start_app_block(a);
      }

    else if(strcmp((a->argv[1]),"status")==0)
      {
	if ((a->argc)==3){
        
	  pairing_status(a->argv[2],a);

	}	
	else{
	  return CLI_SHOWUSAGE;
	}

      }
 
   

    return CLI_SUCCESS;
  }
    
}

static struct ast_cli_entry cli_latch[] = {
  AST_CLI_DEFINE(handle_cli_latch, "Add a new user(device) and token to be controlled by latch"),
};


static int load_module(void)
{
  ast_log(LOG_NOTICE, "Latch Module Load!\n");
  ast_cli_register_multiple(cli_latch, ARRAY_LEN(cli_latch));

  char command[250]= "asterisk -rx \"latch start\" & ";
  system(command);




  return AST_MODULE_LOAD_SUCCESS;
}


static int unload_module(void)
{
  ast_log(LOG_NOTICE, "Latch Module Unload!\n");
  ast_cli_unregister_multiple(cli_latch, ARRAY_LEN(cli_latch));

  char command[150];

  strcpy( command, "pkill -9 -f /etc/asterisk/latch/AppBlockCommunityAccount.jar &" );
  system(command);

  return 0;
}

AST_MODULE_INFO_STANDARD(ASTERISK_GPL_KEY, "Latch");
