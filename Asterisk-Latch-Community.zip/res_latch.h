#ifndef _RES_LATCH_H_
#define _RES_LATCH_H_
#endif

void create(char *pUserID, char *pAppID, char *pSecret,struct ast_cli_args *pa);
int insert_in_table(char *pUserID, char *pAppID, char *pSecret,struct ast_cli_args *pa);
void eliminate(char *pUserID, struct ast_cli_args *pa);
int eliminate_from_table_users(char *pUserID,struct ast_cli_args *pa);
int update_table(char * pUserID,char *pAccountID, struct ast_cli_args *pa);
char *get_accountID(char * pResponse,char pAccountID[],struct ast_cli_args *pa);
void pairing(char *pUserID,char *pToken, struct ast_cli_args *pa);
int select_app_secret(char * pUserID, char papp[],char psecret[], struct ast_cli_args *pa);
void unpairing(char *pUserID, struct ast_cli_args *pa);
int select_accountid(char * pUserID, char pAccountID[], struct ast_cli_args *pa);
int insert_in_table_devices(char *pChannel, char *pOperationID,char *pUserID, char *pAppID, char *pSecret,char *pAccountID,struct ast_cli_args *pa);
char *get_operationID(char * pResponse,char pOperationID[],struct ast_cli_args *pa);
void add_channel(char *pUserID, char *pChannel, struct ast_cli_args *pa);
int channel_exists(char *pChannel,struct ast_cli_args *pa);
void remove_channel(char *pUserID, char *pChannel, struct ast_cli_args *pa);
int select_operationid(char * pChannel, char pOperationID[], struct ast_cli_args *pa);
int eliminate_from_table_devices(char *pChannel,struct ast_cli_args *pa);
int start_app_block(struct ast_cli_args *pa);
int pairing_status(char *pUserID, struct ast_cli_args *pa);
void create_table_devices(struct ast_cli_args *pa);



#define NO_ERROR_DB         0   /* No database errors found */
#define ERROR_DB            1   /* No database errors found */
#define CHANNEL_NOT_EXISTS  2   /* Channel doesn't exist in database*/
#define CHANNEL_EXISTS      3   /* Channel exists in database*/
#define NOT_PAIRED          4   /* Account status "Not Paired"*/
#define PAIRED              5   /* Account status "Paired"*/
